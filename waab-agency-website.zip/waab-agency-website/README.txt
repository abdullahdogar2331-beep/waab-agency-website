# Waab — Premium Digital Agency Website

## Preview on your Chromebook
1. Download `waab-agency-website.zip` and extract it.
2. Open the `waab-agency-website` folder.
3. Double-click `index.html` to preview in Chrome.

## Publish free with GitHub Pages
1. Go to https://github.com/new and create a public repository named `waab-agency-website`.
2. Open the new repository and choose **Add file → Upload files**.
3. Upload `index.html` from this folder and commit the changes.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a minute or two. GitHub Pages will show your live URL on the Pages screen.

## Important before contacting clients
- Replace `hello@waab.studio` in `index.html` with your real agency email.
- Replace `923000000000` in the WhatsApp URL with your real number in international format (Pakistan: 92 + number without the first 0).
- The portfolio items are clearly labeled as concept projects; replace them with real work as you build it.
- Google Fonts loads online. The page still works if the font service is unavailable, using system fallbacks.
